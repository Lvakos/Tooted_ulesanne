﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Tooted
{
    /// <summary>Ostja andmed ja valitud makseviis (arve jaoks).</summary>
    public class MakseAndmed
    {
        public string Nimi { get; init; } = "";
        public string Aadress { get; init; } = "";
        public string Email { get; init; } = "";
        public string Makseviis { get; init; } = "";
        public string KaardiViimased4 { get; init; } = "";

        /// <summary>Näiteks: Visa(**** **** **** 1234)</summary>
        public string KaartArvel => $"{Makseviis}(**** **** **** {KaardiViimased4})";
    }

    public partial class Payment : Form
    {
        /// <summary>Täidetakse, kui kasutaja valis makseviisi ja andmed olid korras.</summary>
        public MakseAndmed? Andmed { get; private set; }

        public Payment() : this(0) { }

        public Payment(float summa)
        {
            InitializeComponent();
            lblSumma.Text = $"Tasuda: {summa:0.00} €";

            foreach (var kaart in new[] { card1, card2, card3 })
            {
                kaart.Click += Makseviis_Click;
                new ToolTip().SetToolTip(kaart, (string)kaart.Tag!);
            }

            Kaardinumber.KeyPress += (s, e) =>
            {
                // ainult numbrid, tühikud ja klahvid nagu Backspace
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != ' ')
                    e.Handled = true;
            };
            Kaardinumber.Leave += (s, e) => Kaardinumber.Text = VormindaKaart(Kaardinumber.Text);

            foreach (var tb in new[] { Address, Nimi, Email, Kaardinumber })
                tb.TextChanged += (s, e) => errorProvider1.SetError((Control)s!, "");
        }

        private void Makseviis_Click(object? sender, EventArgs e)
        {
            if (sender is not Button kaart) return;

            if (!KontrolliAndmed())
            {
                MessageBox.Show("Täida kõik andmed korrektselt enne makseviisi valimist.",
                    "Andmed puudu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string numbrid = AinultNumbrid(Kaardinumber.Text);
            Andmed = new MakseAndmed
            {
                Nimi = Nimi.Text.Trim(),
                Aadress = Address.Text.Trim(),
                Email = Email.Text.Trim(),
                Makseviis = (string)kaart.Tag!,
                KaardiViimased4 = numbrid[^4..]
            };

            DialogResult = DialogResult.OK;
        }

        private bool KontrolliAndmed()
        {
            Control? esimeneViga = null;

            void Viga(Control c, string tekst)
            {
                errorProvider1.SetError(c, tekst);
                esimeneViga ??= c;
            }

            foreach (var c in new Control[] { Address, Nimi, Email, Kaardinumber })
                errorProvider1.SetError(c, "");

            if (Address.Text.Trim().Length < 5)
                Viga(Address, "Sisesta aadress.");
            if (Nimi.Text.Trim().Length < 2)
                Viga(Nimi, "Sisesta nimi.");
            if (!ArveForm.OnEmail(Email.Text))
                Viga(Email, "Sisesta korrektne e-mail.");

            int pikkus = AinultNumbrid(Kaardinumber.Text).Length;
            if (pikkus < 13 || pikkus > 19)
                Viga(Kaardinumber, "Kaardi number peab olema 13–19 numbrit.");

            esimeneViga?.Focus();
            return esimeneViga == null;
        }

        private static string AinultNumbrid(string tekst) =>
            new string(tekst.Where(char.IsDigit).ToArray());

        /// <summary>1234567890123456 → 1234 5678 9012 3456</summary>
        private static string VormindaKaart(string tekst)
        {
            string n = AinultNumbrid(tekst);
            return string.Join(" ", Enumerable.Range(0, (n.Length + 3) / 4)
                .Select(i => n.Substring(i * 4, Math.Min(4, n.Length - i * 4))));
        }
    }
}
